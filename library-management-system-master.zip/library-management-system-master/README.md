# library-management-system
A lightweight library management system built in .NET Core MVC

This is a work in progress!

Follow my YouTube series as I build this application: [YouTube link](https://www.youtube.com/watch?v=WTVcLFTgDqs)
