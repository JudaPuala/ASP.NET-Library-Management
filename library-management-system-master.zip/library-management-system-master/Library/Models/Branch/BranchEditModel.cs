﻿namespace Library.Models.Branch
{
    public class BranchEditModel
    {
        public string BranchName { get; set; }
        public string Telephone { get; set; }
        public string BranchDescription { get; set; }
    }
}
